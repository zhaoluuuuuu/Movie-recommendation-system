USER_CACHE = '{user_id}_user_cached'
ITEM_CACHE = '{user_id}_item_cached'
ALS_CACHE = '{user_id}_als_cached'
